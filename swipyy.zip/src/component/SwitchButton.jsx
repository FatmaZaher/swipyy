import React from "react";

const SwitchButton = () => {
  return (
    <div className="single-item-switch">
      <div className="checkbox">
        <input type="checkbox" name="show" />
      </div>
    </div>
  );
};
export default SwitchButton;
